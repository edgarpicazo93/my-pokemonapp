export const environment = {
  baseUrl: 'https://pokeapi.co/api/v2',
  production: true
};
